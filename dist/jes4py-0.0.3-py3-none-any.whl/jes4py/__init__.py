from jes4py import Config

# Add other "top-level" modules here
from jes4py.media import *
#from jes4py.sound import *
    
Config.initDict()
Config.initPath()
